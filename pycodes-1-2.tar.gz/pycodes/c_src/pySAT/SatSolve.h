
#include"SatGraphAlgorithm.h"

extern SatGraphAlgorithm MesgPassSolveSatAlgorithm;
